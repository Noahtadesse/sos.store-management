import 'index.dart';
// auth_service.dart

class AuthService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<Map<String, dynamic>> login(String accountId, String password) async {
    try {
      print("Login attempt:");
      print("Account ID: $accountId");
      print("Password: $password");

      final String collectionName = 'account';
      print("Accessing collection: $collectionName");

      // Fetch the user document
      final QuerySnapshot userQuery = await _firestore
          .collection(collectionName)
          .where('account_id', isEqualTo: accountId)
          .get();

      if (userQuery.docs.isEmpty) {
        print("No documents found with account_id: $accountId");
        return {'success': false, 'error': 'account_id_not_found'};
      }

      final userDoc = userQuery.docs.first.data() as Map<String, dynamic>;

      // Debug the fetched document
      print("Fetched User Document: $userDoc");

      if (userDoc['account_status'] == 'Blocked') {
        print("Account is blocked for account_id: $accountId");
        return {'success': false, 'error': 'account_blocked'};
      }

      if (userDoc['password'] != password) {
        print("Incorrect password for account_id: $accountId");
        return {'success': false, 'error': 'incorrect_password'};
      }

      // Save the account_id locally
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('account_id', accountId);

      print("User Data: $userDoc");

      return {'success': true, 'user': userDoc};
    } catch (e) {
      print("Error during login: $e");
      return {'success': false, 'error': 'unknown_error'};
    }
  }

  Future<String?> getCurrentAccountId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('account_id');
  }

  Future<Map<String, dynamic>?> getCurrentUserInfo() async {
    final accountId = await getCurrentAccountId();
    if (accountId == null) {
      return null;
    }

    final QuerySnapshot userQuery = await _firestore
        .collection('account')
        .where('account_id', isEqualTo: accountId)
        .get();

    if (userQuery.docs.isEmpty) {
      return null;
    }

    final userDoc = userQuery.docs.first.data() as Map<String, dynamic>;
    final String? firstName = userDoc['f_name'];
    final String? lastName = userDoc['l_name'];

    return {
      'account_id': accountId,
      'f_name': firstName,
      'l_name': lastName,
    };
  }
}

Future<String> _createCustomToken(String uid) async {
  // Assuming you have a Firebase Function to generate the custom token
  HttpsCallable callable =
      FirebaseFunctions.instance.httpsCallable('createCustomToken');
  final response = await callable.call({'uid': uid});
  return response.data['token'];
}
