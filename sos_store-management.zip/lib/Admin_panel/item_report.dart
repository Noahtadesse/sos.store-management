import 'package:flutter/material.dart';

class ItemReport extends StatefulWidget {
  const ItemReport({Key? key}) : super(key: key);

  @override
  ItemReportState createState() => ItemReportState();
}

class ItemReportState extends State<ItemReport> {
  final String userName = 'noah'; // Replace with dynamic data as needed

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff5c3a69),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Hi $userName, how can I help you',
              key: const Key('user_name_text'),
              style: const TextStyle(
                color: Colors.lightGreenAccent,
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
