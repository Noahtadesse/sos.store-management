import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class AccountReport extends StatelessWidget {
  const AccountReport({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Account Report'),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {
              showSearch(
                context: context,
                delegate: CustomAccountReportPageSearchDelegate(),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.close),
            color: Colors.red,
            onPressed: () {
              Navigator.pop(context);
            },
          ),
        ],
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('account').snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return const Center(child: Text('Error fetching data'));
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text('No data available'));
          }

          final items = snapshot.data!.docs;

          // Define text styles
          final TextStyle headerStyle =
              TextStyle(fontWeight: FontWeight.bold, fontSize: 16);
          final TextStyle cellStyle = TextStyle(fontSize: 14);

          return SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: DataTable(
              columns: [
                DataColumn(label: Text('account_id', style: headerStyle)),
                DataColumn(label: Text('f_name', style: headerStyle)),
                DataColumn(label: Text('l_name', style: headerStyle)),
                DataColumn(label: Text('password', style: headerStyle)),
                DataColumn(label: Text('mobile', style: headerStyle)),
                DataColumn(label: Text('account_type', style: headerStyle)),
                DataColumn(
                    label:
                        Text('account_registration_date', style: headerStyle)),
                DataColumn(label: Text('account_status', style: headerStyle)),
                DataColumn(label: Text('Actions', style: headerStyle)),
              ],
              rows: items.map((item) {
                final data = item.data() as Map<String, dynamic>;

                // Convert Timestamp to String
                String registrationDate = '';
                if (data.containsKey('account_registration_date') &&
                    data['account_registration_date'] != null) {
                  if (data['account_registration_date'] is Timestamp) {
                    Timestamp timestamp = data['account_registration_date'];
                    registrationDate = timestamp.toDate().toString();
                  } else if (data['account_registration_date'] is String) {
                    registrationDate = data['account_registration_date'];
                  }
                }

                String currentStatus = data['account_status'] ?? 'Active';

                return DataRow(cells: [
                  DataCell(Text(data['account_id'] ?? '', style: cellStyle)),
                  DataCell(Text(data['f_name'] ?? '', style: cellStyle)),
                  DataCell(Text(data['l_name'] ?? '', style: cellStyle)),
                  DataCell(Text(data['password'] ?? '', style: cellStyle)),
                  DataCell(Text(data['mobile'] ?? '', style: cellStyle)),
                  DataCell(Text(data['account_type'] ?? '', style: cellStyle)),
                  DataCell(Text(registrationDate, style: cellStyle)),
                  DataCell(
                    DropdownButtonFormField<String>(
                      value: currentStatus,
                      items: ['Active', 'Blocked'].map((String status) {
                        return DropdownMenuItem<String>(
                          value: status,
                          child: Text(status),
                        );
                      }).toList(),
                      onChanged: (String? newValue) {
                        if (newValue != null) {
                          FirebaseFirestore.instance
                              .collection('account')
                              .doc(item.id)
                              .update({'account_status': newValue});
                        }
                      },
                      decoration: const InputDecoration(
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  DataCell(
                    IconButton(
                      icon: const Icon(Icons.save),
                      onPressed: () {
                        // Save the updated status to Firebase
                        FirebaseFirestore.instance
                            .collection('account')
                            .doc(item.id)
                            .update({
                          'account_status': currentStatus,
                        });
                      },
                    ),
                  ),
                ]);
              }).toList(),
            ),
          );
        },
      ),
    );
  }
}

class CustomAccountReportPageSearchDelegate extends SearchDelegate<String> {
  @override
  List<Widget> buildActions(BuildContext context) {
    return [
      IconButton(
        icon: const Icon(Icons.clear),
        onPressed: () {
          query = '';
          showSuggestions(context); // Show suggestions when clearing query
        },
      ),
    ];
  }

  @override
  Widget buildLeading(BuildContext context) {
    return IconButton(
      icon: AnimatedIcon(
        icon: AnimatedIcons.menu_arrow,
        progress: transitionAnimation,
      ),
      onPressed: () {
        // Close search with null to indicate no selection
        close(context, '');
      },
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    if (query.isEmpty) {
      return const Center(
        child: Text('Your Account report Page Content'),
      );
    } else {
      return StreamBuilder<QuerySnapshot>(
        stream: query == 'Active' || query == 'Blocked'
            ? FirebaseFirestore.instance
                .collection('account')
                .where('account_status', isEqualTo: query)
                .snapshots()
            : FirebaseFirestore.instance
                .collection('account')
                .where('account_id', isGreaterThanOrEqualTo: query)
                .where('account_id', isLessThanOrEqualTo: query + '\uf8ff')
                .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return const Center(child: Text('Error fetching data'));
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text('No data available'));
          }

          final items = snapshot.data!.docs;

          // Define text styles
          final TextStyle headerStyle =
              TextStyle(fontWeight: FontWeight.bold, fontSize: 16);
          final TextStyle cellStyle = TextStyle(fontSize: 14);

          return SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: DataTable(
              columns: [
                DataColumn(label: Text('account_id', style: headerStyle)),
                DataColumn(label: Text('f_name', style: headerStyle)),
                DataColumn(label: Text('l_name', style: headerStyle)),
                DataColumn(label: Text('password', style: headerStyle)),
                DataColumn(label: Text('mobile', style: headerStyle)),
                DataColumn(label: Text('account_type', style: headerStyle)),
                DataColumn(
                    label:
                        Text('account_registration_date', style: headerStyle)),
                DataColumn(label: Text('account_status', style: headerStyle)),
                DataColumn(label: Text('Actions', style: headerStyle)),
              ],
              rows: items.map((item) {
                final data = item.data() as Map<String, dynamic>;

                // Convert Timestamp to String
                String registrationDate = '';
                if (data.containsKey('account_registration_date') &&
                    data['account_registration_date'] != null) {
                  if (data['account_registration_date'] is Timestamp) {
                    Timestamp timestamp = data['account_registration_date'];
                    registrationDate = timestamp.toDate().toString();
                  } else if (data['account_registration_date'] is String) {
                    registrationDate = data['account_registration_date'];
                  }
                }

                String currentStatus = data['account_status'] ?? 'Active';

                return DataRow(cells: [
                  DataCell(Text(data['account_id'] ?? '', style: cellStyle)),
                  DataCell(Text(data['f_name'] ?? '', style: cellStyle)),
                  DataCell(Text(data['l_name'] ?? '', style: cellStyle)),
                  DataCell(Text(data['password'] ?? '', style: cellStyle)),
                  DataCell(Text(data['mobile'] ?? '', style: cellStyle)),
                  DataCell(Text(data['account_type'] ?? '', style: cellStyle)),
                  DataCell(Text(registrationDate, style: cellStyle)),
                  DataCell(
                    DropdownButtonFormField<String>(
                      value: currentStatus,
                      items: ['Active', 'Blocked'].map((String status) {
                        return DropdownMenuItem<String>(
                          value: status,
                          child: Text(status),
                        );
                      }).toList(),
                      onChanged: (String? newValue) {
                        if (newValue != null) {
                          FirebaseFirestore.instance
                              .collection('account')
                              .doc(item.id)
                              .update({'account_status': newValue});
                        }
                      },
                      decoration: const InputDecoration(
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  DataCell(
                    IconButton(
                      icon: const Icon(Icons.save),
                      onPressed: () {
                        // Save the updated status to Firebase
                        FirebaseFirestore.instance
                            .collection('account')
                            .doc(item.id)
                            .update({
                          'account_status': currentStatus,
                        });
                      },
                    ),
                  ),
                ]);
              }).toList(),
            ),
          );
        },
      );
    }
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    if (query.isEmpty) {
      return Container();
    } else {
      return StreamBuilder<QuerySnapshot>(
        stream: query == 'Active' || query == 'Blocked'
            ? FirebaseFirestore.instance
                .collection('account')
                .where('account_status', isEqualTo: query)
                .snapshots()
            : FirebaseFirestore.instance
                .collection('account')
                .where('account_id', isGreaterThanOrEqualTo: query)
                .where('account_id', isLessThanOrEqualTo: query + '\uf8ff')
                .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return const Center(child: Text('Error fetching data'));
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text('No data available'));
          }

          final items = snapshot.data!.docs;

          return ListView.builder(
            itemCount: items.length,
            itemBuilder: (context, index) {
              final data = items[index].data() as Map<String, dynamic>;

              return ListTile(
                title: Text(data['account_id'] ?? ''),
                subtitle: Text(data['f_name'] ?? ''),
                onTap: () {
                  query = data['account_id'] ?? '';
                  showResults(context);
                },
              );
            },
          );
        },
      );
    }
  }
}
