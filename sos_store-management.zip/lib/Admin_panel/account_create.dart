import 'package:form_field_validator/form_field_validator.dart';
import 'package:sos_store_management/index.dart';
import 'package:intl/intl.dart'; // Import for date formatting

class AccountCreate extends StatefulWidget {
  const AccountCreate({Key? key}) : super(key: key);

  @override
  AccountCreateState createState() => AccountCreateState();
}

class AccountCreateState extends State<AccountCreate> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _idController = TextEditingController();
  final TextEditingController _firstNameController = TextEditingController();
  final TextEditingController _lastNameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _mobileController = TextEditingController();
  final TextEditingController _dateController = TextEditingController();
  String _selectedAccountType = 'ict_personnel';
  String _selectedAccountStatus = 'Active';

  @override
  void initState() {
    super.initState();
    _dateController.text = DateFormat('yyyy-MM-dd').format(DateTime.now());
  }

  // Function to reset the form field
  void _resetForm() {
    _formKey.currentState!.reset();
    _idController.clear();
    _firstNameController.clear();
    _lastNameController.clear();
    _passwordController.clear();
    _mobileController.clear();
    _dateController.text = DateFormat('yyyy-MM-dd').format(DateTime.now());
    setState(() {
      _selectedAccountType = 'ict_personnel';
      _selectedAccountStatus = 'Active';
    });
  }

  Future<void> _registerAccount() async {
    if (_formKey.currentState!.validate()) {
      try {
        await FirebaseFirestore.instance.collection('account').add({
          'account_id': _idController.text,
          'f_name': _firstNameController.text,
          'l_name': _lastNameController.text,
          'password': _passwordController.text,
          'mobile': _mobileController.text,
          'account_registration_date': _dateController.text,
          'account_status': _selectedAccountStatus,
          'account_type': _selectedAccountType,
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Account registered successfully!')),
        );
        _resetForm();
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    }
  }

  @override
  void dispose() {
    _idController.dispose();
    _firstNameController.dispose();
    _lastNameController.dispose();
    _passwordController.dispose();
    _mobileController.dispose();
    _dateController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Register'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextFormField(
                    controller: _idController,
                    validator: MultiValidator([
                      RequiredValidator(errorText: 'Enter user ID'),
                      MinLengthValidator(4,
                          errorText: 'Minimum 4 characters required for ID'),
                    ]),
                    decoration: const InputDecoration(
                      hintText: 'Enter ID',
                      labelText: 'ID',
                      prefixIcon: Icon(Icons.badge, color: Colors.green),
                      errorStyle: TextStyle(fontSize: 18.0),
                      border: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.red),
                        borderRadius: BorderRadius.all(Radius.circular(9.0)),
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextFormField(
                    controller: _firstNameController,
                    validator: MultiValidator([
                      RequiredValidator(errorText: 'Enter first name'),
                      MinLengthValidator(3,
                          errorText:
                              'Minimum 3 characters required for first name'),
                    ]),
                    decoration: const InputDecoration(
                      hintText: 'Enter first name',
                      labelText: 'First Name',
                      prefixIcon: Icon(Icons.person, color: Colors.green),
                      errorStyle: TextStyle(fontSize: 18.0),
                      border: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.red),
                        borderRadius: BorderRadius.all(Radius.circular(9.0)),
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextFormField(
                    controller: _lastNameController,
                    validator: MultiValidator([
                      RequiredValidator(errorText: 'Enter last name'),
                      MinLengthValidator(3,
                          errorText:
                              'Minimum 3 characters required for last name'),
                    ]),
                    decoration: const InputDecoration(
                      hintText: 'Enter last name',
                      labelText: 'Last Name',
                      prefixIcon: Icon(Icons.person, color: Colors.grey),
                      errorStyle: TextStyle(fontSize: 18.0),
                      border: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.red),
                        borderRadius: BorderRadius.all(Radius.circular(9.0)),
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextFormField(
                    controller: _passwordController,
                    validator: MultiValidator([
                      RequiredValidator(errorText: 'Enter Password'),
                      MinLengthValidator(6,
                          errorText:
                              'Minimum 6 characters required for password'),
                    ]),
                    decoration: const InputDecoration(
                      hintText: 'Password',
                      labelText: 'Password',
                      prefixIcon: Icon(Icons.password, color: Colors.lightBlue),
                      errorStyle: TextStyle(fontSize: 18.0),
                      border: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.red),
                        borderRadius: BorderRadius.all(Radius.circular(9.0)),
                      ),
                    ),
                    obscureText: true,
                  ),
                ),
                const SizedBox(height: 4),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextFormField(
                    controller: _mobileController,
                    validator: MultiValidator([
                      RequiredValidator(errorText: 'Enter mobile number'),
                      PatternValidator(r'^\d{10}$',
                          errorText: 'Enter a valid 10-digit mobile number'),
                    ]),
                    decoration: const InputDecoration(
                      hintText: 'Mobile',
                      labelText: 'Mobile',
                      prefixIcon: Icon(Icons.phone, color: Colors.grey),
                      border: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.red),
                        borderRadius: BorderRadius.all(Radius.circular(9)),
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextFormField(
                    controller: _dateController,
                    validator: RequiredValidator(
                        errorText: 'Please enter registration date'),
                    readOnly: true,
                    decoration: const InputDecoration(
                      hintText: 'Select registration date',
                      labelText: 'Registration Date',
                      prefixIcon:
                          Icon(Icons.calendar_today, color: Colors.green),
                      errorStyle: TextStyle(fontSize: 18.0),
                      border: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.red),
                        borderRadius: BorderRadius.all(Radius.circular(9.0)),
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: DropdownButtonFormField<String>(
                    value: _selectedAccountType,
                    onChanged: (String? newValue) {
                      setState(() {
                        _selectedAccountType = newValue!;
                      });
                    },
                    validator: RequiredValidator(
                        errorText: 'Please select account type'),
                    decoration: const InputDecoration(
                      labelText: 'Account Type',
                      prefixIcon:
                          Icon(Icons.account_circle, color: Colors.green),
                      border: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.red),
                        borderRadius: BorderRadius.all(Radius.circular(9.0)),
                      ),
                    ),
                    items: <String>['ict_personnel', 'Store manager', 'Admin']
                        .map<DropdownMenuItem<String>>((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(value),
                      );
                    }).toList(),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: DropdownButtonFormField<String>(
                    value: _selectedAccountStatus,
                    onChanged: (String? newValue) {
                      setState(() {
                        _selectedAccountStatus = newValue!;
                      });
                    },
                    validator: RequiredValidator(
                        errorText: 'Please select account Status'),
                    decoration: const InputDecoration(
                      labelText: 'Account Status',
                      prefixIcon:
                          Icon(Icons.account_circle, color: Colors.green),
                      border: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.red),
                        borderRadius: BorderRadius.all(Radius.circular(9.0)),
                      ),
                    ),
                    items: <String>['Active', 'Blocked']
                        .map<DropdownMenuItem<String>>((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(value),
                      );
                    }).toList(),
                  ),
                ),
                Center(
                  child: Padding(
                    padding: const EdgeInsets.all(18.0),
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      height: 50,
                      child: ElevatedButton(
                        onPressed: _registerAccount,
                        style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30),
                          ),
                          backgroundColor: Colors.blue,
                        ),
                        child: const Text(
                          'Register',
                          style: TextStyle(color: Colors.white, fontSize: 22),
                        ),
                      ),
                    ),
                  ),
                ),
                Center(
                  child: Padding(
                    padding: const EdgeInsets.all(18.0),
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      height: 50,
                      child: ElevatedButton(
                        onPressed: _resetForm,
                        style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30),
                          ),
                          backgroundColor: Colors.red,
                        ),
                        child: const Text(
                          'Cancel',
                          style: TextStyle(color: Colors.white, fontSize: 22),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
