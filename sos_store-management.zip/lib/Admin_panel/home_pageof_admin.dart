import 'package:sos_store_management/index.dart';

class Adminpage extends StatefulWidget {
  const Adminpage({super.key});

  @override
  AdminpageState createState() => AdminpageState();
}

class AdminpageState extends State<Adminpage> {
  late Future<String> _userNameFuture;

  @override
  void initState() {
    super.initState();
    _userNameFuture = _fetchUserName();
  }

  Future<String> _fetchUserName() async {
    final userInfo = await AuthService().getCurrentUserInfo();
    return userInfo?['f_name'] ?? 'Admin';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffeceaea),
      body: Center(
        child: FutureBuilder<String>(
          future: _userNameFuture,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const CircularProgressIndicator();
            }
            if (snapshot.hasError) {
              return const Text('Error fetching user name');
            }
            if (!snapshot.hasData || snapshot.data!.isEmpty) {
              return const Text('No user name available');
            }

            final userName = snapshot.data!;

            return Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Hi $userName, HOW can I help you',
                  key: const Key('user_name_text'),
                  style: const TextStyle(
                    color: Color(0xff4aeaf6),
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 50),
                Wrap(
                  spacing: 20,
                  runSpacing: 20,
                  alignment: WrapAlignment.center,
                  children: [
                    _buildSizedButton(
                      key: const Key('create_acc'),
                      label: 'CREATE ACCOUNT',
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const AccountCreate()),
                        );
                      },
                    ),
                    _buildSizedButton(
                      key: const Key('Account_report'),
                      label: "ACCOUNT'S REPORT",
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const AccountReport()),
                        );
                      },
                    ),
                  ],
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _buildSizedButton({
    required Key key,
    required String label,
    required VoidCallback onPressed,
  }) {
    return SizedBox(
      width: 300, // Set the desired width
      height: 60, // Set the desired height
      child: ElevatedButton(
        key: key,
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.white,
          foregroundColor: Colors.black,
          textStyle: const TextStyle(fontSize: 18),
        ),
        child: Text(label),
      ),
    );
  }
}
