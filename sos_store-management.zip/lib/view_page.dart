import 'package:sos_store_management/index.dart';

class ViewPage extends StatelessWidget {
  const ViewPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('View Page'),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {
              showSearch(
                context: context,
                delegate: CustomViewPageSearchDelegate(),
              );
            },
          ),
        ],
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('items').snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return const Center(child: Text('Error fetching data'));
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text('No data available'));
          }

          final items = snapshot.data!.docs;

          return SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: DataTable(
              columns: const [
                DataColumn(label: Text('Part Number(SN)')),
                DataColumn(label: Text('Brand')),
                DataColumn(label: Text('Category')),
                DataColumn(label: Text('Description')),
                DataColumn(label: Text('GRR Receipt')),
                DataColumn(label: Text('Item Registration Date')),
                DataColumn(label: Text('Model')),
                DataColumn(label: Text('Current Holder')),
              ],
              rows: items.map((item) {
                final data = item.data() as Map<String, dynamic>;
                final grrReceiptUrl = data['grr_receipt'] ?? '';

                return DataRow(
                  cells: [
                    DataCell(
                      Text(data['part_number(sn)'] ?? ''),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => ItemDetailPage(
                              partNumber: data['part_number(sn)'] ?? '',
                            ),
                          ),
                        );
                      },
                    ),
                    DataCell(Text(data['brand'] ?? '')),
                    DataCell(Text(data['category'] ?? '')),
                    DataCell(Text(data['description'] ?? '')),
                    DataCell(
                      grrReceiptUrl.isNotEmpty
                          ? GestureDetector(
                              onTap: () {
                                showDialog(
                                  context: context,
                                  builder: (BuildContext context) {
                                    return Dialog(
                                      child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Image.network(grrReceiptUrl),
                                          TextButton(
                                            onPressed: () {
                                              Navigator.of(context).pop();
                                            },
                                            child: const Text('Close'),
                                          ),
                                        ],
                                      ),
                                    );
                                  },
                                );
                              },
                              child: Image.network(
                                grrReceiptUrl,
                                width: 100,
                                height: 100,
                                fit: BoxFit.cover,
                              ),
                            )
                          : const Text('No Image'),
                    ),
                    DataCell(
                      Text(
                        data['item_registration_date'] is Timestamp
                            ? (data['item_registration_date'] as Timestamp)
                                .toDate()
                                .toString()
                            : data['item_registration_date'] ?? '',
                      ),
                    ),
                    DataCell(Text(data['model'] ?? '')),
                    DataCell(Text(data['current_holder'] ?? '')),
                  ],
                );
              }).toList(),
            ),
          );
        },
      ),
    );
  }
}
