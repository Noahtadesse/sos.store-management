import 'package:cloud_firestore/cloud_firestore.dart';

class Record {
  final String accountId;
  final Timestamp accountRegistrationDate;
  final String accountStatus;
  final String accountType;
  final String firstName;
  final String lastName;
  final String password;
  final DocumentReference reference;

  Record({
    required this.accountId,
    required this.accountRegistrationDate,
    required this.accountStatus,
    required this.accountType,
    required this.firstName,
    required this.lastName,
    required this.password,
    required this.reference,
  });

  factory Record.fromMap(
      Map<String, dynamic> map, DocumentReference reference) {
    return Record(
      accountId: map['account_id'],
      accountRegistrationDate: map['account_registration_date'],
      accountStatus: map['account_status'],
      accountType: map['account_type'],
      firstName: map['f_name'],
      lastName: map['l_name'],
      password: map['password'],
      reference: reference,
    );
  }

  factory Record.fromSnapshot(DocumentSnapshot snapshot) {
    final data = snapshot.data() as Map<String, dynamic>;
    return Record.fromMap(data, snapshot.reference);
  }

  @override
  String toString() {
    return "Record<$accountId:$accountStatus>";
  }
}
