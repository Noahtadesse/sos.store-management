import 'index.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
  } catch (e) {
    debugPrint(
        'Error initializing Firebase: $e'); // Use debugPrint instead of print
  }
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Login page',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const LoginPage(),
      routes: {
        '/HomePage': (context) => const HomePage(), // Store manager home page
        '/home_ict_personnel': (context) =>
            const HomePageOfIctPersonnel(), // ICT personnel home page
        '/admin_page': (context) => const Adminpage(), // Admin page
      },
      onUnknownRoute: (settings) {
        return MaterialPageRoute(builder: (context) {
          return Scaffold(
            appBar: AppBar(
              title: const Text('Error'),
            ),
            body: const Center(
              child: Text('Page not found'),
            ),
          );
        });
      },
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  LoginPageState createState() =>
      LoginPageState(); // Avoid using private class names in public APIs
}

class LoginPageState extends State<LoginPage> {
  final TextEditingController _accountIdController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final AuthService _authService = AuthService();

  @override
  void dispose() {
    _accountIdController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    if (_formKey.currentState!.validate()) {
      String accountId = _accountIdController.text;
      String password = _passwordController.text;

      ScaffoldMessengerState scaffoldMessenger = ScaffoldMessenger.of(context);
      NavigatorState navigator = Navigator.of(context);

      try {
        Map<String, dynamic> result =
            await _authService.login(accountId, password);

        if (result['success']) {
          scaffoldMessenger.showSnackBar(
            const SnackBar(content: Text('Login successful')),
          );

          String userAccountType = result['user']['account_type'];
          if (userAccountType == 'ict_personnel') {
            navigator.pushNamed('/home_ict_personnel');
          } else if (userAccountType == 'Admin') {
            navigator.pushNamed('/admin_page');
          } else if (userAccountType == 'Store manager') {
            navigator.pushNamed('/HomePage');
          } else {
            scaffoldMessenger.showSnackBar(
              const SnackBar(content: Text('Invalid account type')),
            );
          }
        } else {
          String error = result['error'];
          String errorMessage = '';
          if (error == 'account_id_not_found') {
            errorMessage = 'Account ID not found';
          } else if (error == 'incorrect_password') {
            errorMessage = 'Incorrect password';
          } else if (error == 'account_blocked') {
            errorMessage = 'Account is blocked';
          } else {
            errorMessage = 'Login failed';
          }
          scaffoldMessenger.showSnackBar(
            SnackBar(content: Text(errorMessage)),
          );
        }
      } catch (e) {
        scaffoldMessenger.showSnackBar(
          SnackBar(content: Text('An error occurred: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffeef9f9),
      body: Center(
        child: LayoutBuilder(
          builder: (context, constraints) {
            double width =
                constraints.maxWidth > 600 ? 600 : constraints.maxWidth * 0.9;
            return Padding(
              padding: const EdgeInsets.all(16.0),
              child: Card(
                color: Colors.white,
                elevation: 5,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Form(
                    key: _formKey,
                    child: Container(
                      width: width,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          TextFormField(
                            controller: _accountIdController,
                            decoration: InputDecoration(
                              labelText: 'Account ID',
                              filled: true,
                              fillColor: Colors.blue[50],
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                            ),
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please enter your account ID';
                              }
                              return null;
                            },
                          ),
                          const SizedBox(height: 20),
                          TextFormField(
                            controller: _passwordController,
                            decoration: InputDecoration(
                              labelText: 'Password',
                              filled: true,
                              fillColor: Colors.blue[50],
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                            ),
                            obscureText: true,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please enter your password';
                              }
                              return null;
                            },
                          ),
                          const SizedBox(height: 20),
                          ElevatedButton(
                            onPressed: _login,
                            style: ElevatedButton.styleFrom(
                              foregroundColor: Colors.white,
                              backgroundColor: Colors.blue,
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 80, vertical: 20),
                              textStyle: const TextStyle(fontSize: 18),
                            ),
                            child: const Text('SIGN IN'),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
