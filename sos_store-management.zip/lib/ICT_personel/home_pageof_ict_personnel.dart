import 'package:sos_store_management/index.dart';

class HomePageOfIctPersonnel extends StatefulWidget {
  const HomePageOfIctPersonnel({super.key});

  @override
  HomePageOfIctPersonnelState createState() => HomePageOfIctPersonnelState();
}

class HomePageOfIctPersonnelState extends State<HomePageOfIctPersonnel> {
  String userName = 'loading...';

  @override
  void initState() {
    super.initState();
    _fetchUserName();
  }

  Future<void> _fetchUserName() async {
    final authService = AuthService();
    final userInfo = await authService.getCurrentUserInfo();

    print("User info fetched: $userInfo"); // Debug statement

    if (userInfo != null) {
      setState(() {
        userName = userInfo['f_name'] ?? 'User';
      });
      print("User name set to: $userName"); // Debug statement
    } else {
      print("User info is null"); // Debug statement
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffeceaea),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Hi, $userName',
              key: const Key('user_name_text'),
              style: const TextStyle(
                color: Color(0xff4aeaf6),
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 50),
            Wrap(
              spacing: 20,
              runSpacing: 20,
              alignment: WrapAlignment.center,
              children: [
                ElevatedButton(
                  key: const Key('view_button'),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const ViewPage()),
                    );
                  },
                  child: const Text('View'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
