import 'package:sos_store_management/index.dart';

class ReturnedItemPage extends StatelessWidget {
  const ReturnedItemPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Returned Item Page'),
        actions: [
          IconButton(
            icon: const Icon(Icons.search, color: Colors.blue),
            onPressed: () {
              showSearch(
                context: context,
                delegate: CustomReturnItemSearchDelegate(),
              );
            },
          ),
        ],
      ),
      body: ReturnedItemsList(),
    );
  }
}

class ReturnedItemsList extends StatelessWidget {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<QuerySnapshot>(
      future: _firestore
          .collection('items')
          .where('current_holder', isNotEqualTo: 'Available')
          .get(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) {
          return Center(child: Text('Error fetching data: ${snapshot.error}'));
        }
        if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
          return const Center(child: Text('No distributed items'));
        }

        final items = snapshot.data!.docs;

        return ListView.builder(
          itemCount: items.length,
          itemBuilder: (context, index) {
            final item = items[index].data() as Map<String, dynamic>;
            final partNumber = item['part_number(sn)'] ?? '';
            final currentHolder = item['current_holder'] ?? '';

            return ListTile(
              title: Text(partNumber),
              subtitle: Text('Current Holder: $currentHolder'),
              onTap: () {
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      title: const Text('Return Item'),
                      content: ReturnForm(partNumber: partNumber),
                      actions: [
                        TextButton(
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                          child: const Text('Cancel'),
                        ),
                      ],
                    );
                  },
                );
              },
            );
          },
        );
      },
    );
  }
}

class ReturnForm extends StatefulWidget {
  final String partNumber;

  const ReturnForm({required this.partNumber, Key? key}) : super(key: key);

  @override
  _ReturnFormState createState() => _ReturnFormState();
}

class _ReturnFormState extends State<ReturnForm> {
  final _formKey = GlobalKey<FormState>();
  final _detailsController = TextEditingController();
  String? _accountId;
  PlatformFile? _selectedFile;
  Map<String, dynamic>? _itemData;
  String? _documentId; // Store the document ID

  @override
  void initState() {
    super.initState();
    _loadAccountId();
    _fetchItemData();
  }

  Future<void> _loadAccountId() async {
    String? account_Id = await AuthService().getCurrentAccountId();
    setState(() {
      _accountId = account_Id;
    });
  }

  Future<void> _fetchItemData() async {
    try {
      QuerySnapshot snapshot = await FirebaseFirestore.instance
          .collection('items')
          .where('part_number(sn)', isEqualTo: widget.partNumber)
          .limit(1)
          .get();
      if (snapshot.docs.isNotEmpty) {
        setState(() {
          _itemData = snapshot.docs.first.data() as Map<String, dynamic>;
          _documentId = snapshot.docs.first.id; // Store the document ID
        });
      }
    } catch (e) {
      print('Error fetching item data: $e');
      // Handle the error accordingly
    }
  }

  Future<void> _selectImage() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.image,
      allowMultiple: false,
    );

    if (result != null) {
      setState(() {
        _selectedFile = result.files.first;
      });
    }
  }

  Future<String> _uploadImage() async {
    if (_selectedFile == null) {
      throw Exception('No file selected');
    }

    try {
      Uint8List? fileBytes = _selectedFile!.bytes;

      if (fileBytes == null) {
        throw Exception('File is empty or corrupted');
      }

      String uniqueFileName = DateTime.now().millisecondsSinceEpoch.toString();
      Reference referenceRoot = FirebaseStorage.instance.ref();
      Reference referenceDirImages = referenceRoot.child('grr_receipt');
      Reference referenceImageToUpload =
          referenceDirImages.child(uniqueFileName);

      String? mimeType = lookupMimeType(_selectedFile!.name);
      SettableMetadata metadata = SettableMetadata(contentType: mimeType);

      await referenceImageToUpload.putData(fileBytes, metadata);
      return await referenceImageToUpload.getDownloadURL();
    } on FirebaseException catch (e) {
      throw Exception('Firebase error: ${e.message}');
    } catch (error, stackTrace) {
      print('Error uploading image: $error');
      print('Stack Trace: $stackTrace');
      throw Exception('Error uploading image: $error');
    }
  }

  Future<void> returnItem() async {
    if (_formKey.currentState?.validate() ?? false) {
      try {
        final imageUrl = await _uploadImage();

        final partNumber = widget.partNumber;
        final returnId =
            FirebaseFirestore.instance.collection('returned_item').doc().id;
        final returnData = {
          'details': _detailsController.text,
          'grr_receipt': imageUrl,
          'account_id': _accountId,
        };

        await FirebaseFirestore.instance.runTransaction((transaction) async {
          final itemRef =
              FirebaseFirestore.instance.collection('items').doc(_documentId);
          final returnRef = FirebaseFirestore.instance
              .collection('returned_item')
              .doc(returnId);

          final itemDoc = await transaction.get(itemRef);

          if (!itemDoc.exists) {
            throw Exception('Item does not exist!');
          }

          await transaction.update(itemRef, {
            'status': 'Available',
            'current_holder': 'Available',
            'grr_receipt': returnData['grr_receipt'],
          });

          await transaction.set(returnRef, {
            'part_number(sn)': partNumber,
            'return_date': FieldValue.serverTimestamp(),
            ...returnData,
            'return_id': returnId,
          });
        });

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Item returned successfully!')),
        );
        Navigator.of(context).pop(); // Close the dialog after return
      } catch (error, stackTrace) {
        print('Error returning item: $error');
        print('Stack Trace: $stackTrace');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: ${error.toString()}')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return _itemData == null
        ? Center(child: CircularProgressIndicator())
        : Padding(
            padding: const EdgeInsets.all(16.0),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TextFormField(
                    initialValue: _itemData!['part_number(sn)'],
                    decoration: const InputDecoration(labelText: 'Part Number'),
                    enabled: false,
                  ),
                  TextFormField(
                    controller: _detailsController,
                    decoration:
                        const InputDecoration(labelText: 'Return Details'),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter the return details';
                      }
                      return null;
                    },
                  ),
                  SizedBox(height: 16), // Add spacing
                  IconButton(
                    onPressed: _selectImage,
                    icon: const Icon(Icons.camera_alt),
                    color: Colors.blue,
                    tooltip: 'Select Image',
                  ),
                  SizedBox(height: 16), // Add spacing
                  ElevatedButton(
                    onPressed: returnItem,
                    child: const Text('Return Item'),
                    style: ElevatedButton.styleFrom(
                      minimumSize: Size(double.infinity, 50),
                    ),
                  ),
                ],
              ),
            ),
          );
  }
}

class CustomReturnItemSearchDelegate extends SearchDelegate<String> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  @override
  List<Widget> buildActions(BuildContext context) {
    return [
      IconButton(
        icon: const Icon(Icons.clear),
        onPressed: () {
          query = '';
          showSuggestions(context);
        },
      ),
    ];
  }

  @override
  Widget buildLeading(BuildContext context) {
    return IconButton(
      icon: const Icon(Icons.arrow_back),
      onPressed: () {
        close(context, '');
      },
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    if (query.isEmpty) {
      return const Center(child: Text('Please enter a search term.'));
    } else {
      return FutureBuilder<QuerySnapshot>(
        future: _firestore
            .collection('items')
            .where('part_number(sn)', isGreaterThanOrEqualTo: query)
            .where('part_number(sn)', isLessThanOrEqualTo: query + '\uf8ff')
            .get(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(
                child: Text('Error fetching data: ${snapshot.error}'));
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text('No items found'));
          }

          final items = snapshot.data!.docs;

          return ListView.builder(
            itemCount: items.length,
            itemBuilder: (context, index) {
              final item = items[index].data() as Map<String, dynamic>;
              final partNumber = item['part_number(sn)'] ?? '';
              final currentHolder = item['current_holder'] ?? '';

              return ListTile(
                title: Text(partNumber),
                subtitle: Text('Current Holder: $currentHolder'),
                onTap: () {
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        title: const Text('Return Item'),
                        content: ReturnForm(partNumber: partNumber),
                        actions: [
                          TextButton(
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                            child: const Text('Cancel'),
                          ),
                        ],
                      );
                    },
                  );
                },
              );
            },
          );
        },
      );
    }
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    return Container();
  }
}
