import 'package:sos_store_management/index.dart';
// import 'returned_item_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  HomePageState createState() => HomePageState();
}

class HomePageState extends State<HomePage> {
  late Future<String> _userNameFuture;

  @override
  void initState() {
    super.initState();
    _userNameFuture = _fetchUserName();
  }

  Future<String> _fetchUserName() async {
    final userInfo = await AuthService().getCurrentUserInfo();
    return userInfo?['f_name'] ?? 'User';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xffeef9f9),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: FutureBuilder<String>(
            future: _userNameFuture,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }
              if (snapshot.hasError) {
                return const Center(child: Text('Error fetching user name'));
              }
              if (!snapshot.hasData || snapshot.data!.isEmpty) {
                return const Center(child: Text('No user name available'));
              }

              final userName = snapshot.data!;

              return Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Hi $userName, how can I help you?',
                    key: const Key('user_name_text'),
                    style: const TextStyle(
                      color: Color(0xff4aeaf6),
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 50),
                  Wrap(
                    spacing: 20,
                    runSpacing: 20,
                    alignment: WrapAlignment.center,
                    children: [
                      _buildSizedButton(
                        key: const Key('view_button'),
                        label: 'View',
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const ViewPage()),
                          );
                        },
                      ),
                      _buildSizedButton(
                        key: const Key('distribute_item_button'),
                        label: 'Distribute Item',
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    const DistributeItemPage()),
                          );
                        },
                      ),
                      _buildSizedButton(
                        key: const Key('register_button'),
                        label: 'Item Registration',
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const RegisterItemPage()),
                          );
                        },
                      ),
                      _buildSizedButton(
                        key: const Key('returned_item_button'),
                        label: 'Returned Item',
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const ReturnedItemPage()),
                          );
                        },
                      ),
                    ],
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildSizedButton({
    required Key key,
    required String label,
    required VoidCallback onPressed,
  }) {
    return SizedBox(
      width: 200, // Set the desired width
      height: 60, // Set the desired height
      child: ElevatedButton(
        key: key,
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.white,
          foregroundColor: Colors.black,
          textStyle: const TextStyle(fontSize: 18),
        ),
        child: Text(label),
      ),
    );
  }
}
