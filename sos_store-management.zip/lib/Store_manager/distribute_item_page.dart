import 'package:sos_store_management/index.dart';

class DistributeItemPage extends StatelessWidget {
  const DistributeItemPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Distribute Item Page'),
        actions: [
          IconButton(
            icon: const Icon(Icons.search, color: Colors.blue),
            onPressed: () {
              showSearch(
                context: context,
                delegate: CustomItemViewSearchDelegate(),
              );
            },
          ),
        ],
      ),
      body: AvailableItemsList(),
    );
  }
}

class AvailableItemsList extends StatelessWidget {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<QuerySnapshot>(
      future: _firestore
          .collection('items')
          .where('current_holder', isEqualTo: 'Available')
          .get(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) {
          return Center(child: Text('Error fetching data: ${snapshot.error}'));
        }
        if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
          return const Center(child: Text('No available items'));
        }

        final items = snapshot.data!.docs;

        return ListView.builder(
          itemCount: items.length,
          itemBuilder: (context, index) {
            final item = items[index].data() as Map<String, dynamic>;
            final partNumber = item['part_number(sn)'] ?? '';
            final currentHolder = item['current_holder'] ?? '';

            return ListTile(
              title: Text(partNumber),
              subtitle: Text('Current Holder: $currentHolder'),
              onTap: () {
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      title: const Text('Distribute Item'),
                      content: DistributeForm(partNumber: partNumber),
                      actions: [
                        TextButton(
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                          child: const Text('Cancel'),
                        ),
                      ],
                    );
                  },
                );
              },
            );
          },
        );
      },
    );
  }
}

class CustomItemViewSearchDelegate extends SearchDelegate<String> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  @override
  List<Widget> buildActions(BuildContext context) {
    return [
      IconButton(
        icon: const Icon(Icons.clear),
        onPressed: () {
          query = '';
          showSuggestions(context);
        },
      ),
    ];
  }

  @override
  Widget buildLeading(BuildContext context) {
    return IconButton(
      icon: const Icon(Icons.arrow_back),
      onPressed: () {
        close(context, '');
      },
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    if (query.isEmpty) {
      return const Center(child: Text('Please enter a search term.'));
    } else {
      return FutureBuilder<QuerySnapshot>(
        future: _firestore
            .collection('items')
            .where('part_number(sn)', isGreaterThanOrEqualTo: query)
            .where('part_number(sn)', isLessThanOrEqualTo: query + '\uf8ff')
            .get(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(
                child: Text('Error fetching data: ${snapshot.error}'));
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text('No data available'));
          }

          final items = snapshot.data!.docs;

          return ListView.builder(
            itemCount: items.length,
            itemBuilder: (context, index) {
              final item = items[index].data() as Map<String, dynamic>;
              final partNumber = item['part_number(sn)'] ?? '';
              final currentHolder = item['current_holder'] ?? 'Available';

              return ListTile(
                title: Text(partNumber),
                subtitle: Text('Current Holder: $currentHolder'),
                onTap: () async {
                  final itemRef =
                      _firestore.collection('items').doc(items[index].id);
                  try {
                    final itemDoc = await itemRef.get();

                    if (itemDoc.exists) {
                      final itemData = itemDoc.data() as Map<String, dynamic>;

                      if (itemData['current_holder'] == 'Available') {
                        showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            return AlertDialog(
                              title: const Text('Distribute Item'),
                              content: DistributeForm(partNumber: partNumber),
                              actions: [
                                TextButton(
                                  onPressed: () {
                                    Navigator.of(context).pop();
                                  },
                                  child: const Text('Cancel'),
                                ),
                              ],
                            );
                          },
                        );
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                              content: Text('Item is already distributed')),
                        );
                      }
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Item not found')),
                      );
                    }
                  } catch (e, stackTrace) {
                    print('Error fetching item details: $e');
                    print('Stack trace: $stackTrace');
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                          content: Text('Error fetching item details: $e')),
                    );
                  }
                },
              );
            },
          );
        },
      );
    }
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    return Container(); // Customize if needed
  }
}

class DistributeForm extends StatefulWidget {
  final String partNumber;

  const DistributeForm({required this.partNumber, Key? key}) : super(key: key);

  @override
  _DistributeFormState createState() => _DistributeFormState();
}

class _DistributeFormState extends State<DistributeForm> {
  final _formKey = GlobalKey<FormState>();
  final _receiverNameController = TextEditingController();
  final _projectNameController = TextEditingController();
  final _distributionTypeController = TextEditingController();
  String? _accountId; // Assume you have a method to fetch accountId
  String? _imageUrl;

  @override
  void initState() {
    super.initState();
    _getCurrentAccountId().then((accountId) {
      setState(() {
        _accountId = accountId;
      });
    }).catchError((error) {
      print('Error getting account ID: $error');
    });
  }

  Future<void> _uploadImage() async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.image,
        allowMultiple: false,
      );

      if (result == null) {
        throw Exception('No file selected.');
      }

      PlatformFile file = result.files.first;
      Uint8List? fileBytes = file.bytes;

      if (fileBytes == null) {
        throw Exception('File is empty or corrupted.');
      }

      String uniqueFileName = DateTime.now().millisecondsSinceEpoch.toString();
      Reference referenceRoot = FirebaseStorage.instance.ref();
      Reference referenceDirImages = referenceRoot.child('SIV_receipt');
      Reference referenceImageToUpload =
          referenceDirImages.child(uniqueFileName);

      String? mimeType = lookupMimeType(file.name);
      SettableMetadata metadata = SettableMetadata(
        contentType: mimeType,
      );

      await referenceImageToUpload.putData(fileBytes, metadata);
      String downloadURL = await referenceImageToUpload.getDownloadURL();

      setState(() {
        _imageUrl = downloadURL;
      });
    } catch (e, stackTrace) {
      print('Error uploading image: $e');
      print('Stack trace: $stackTrace');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error uploading image: $e')),
      );
    }
  }

  Future<void> _distributeItem() async {
    if (!_formKey.currentState!.validate() || _imageUrl == null) {
      return;
    }

    final receiverName = _receiverNameController.text;
    final projectName = _projectNameController.text;
    final distributionType = _distributionTypeController.text;

    try {
      await FirebaseFirestore.instance.runTransaction((transaction) async {
        final itemCollection = FirebaseFirestore.instance.collection('items');
        final distributionRef =
            FirebaseFirestore.instance.collection('item_distributions').doc();

        // Query the item document using the part_number(sn) field
        final itemQuery = await itemCollection
            .where('part_number(sn)', isEqualTo: widget.partNumber)
            .limit(1)
            .get();

        if (itemQuery.docs.isEmpty) {
          throw Exception('Item not found in the items collection.');
        }

        final itemDoc = itemQuery.docs.first;
        // final itemId = itemDoc.id;

        // Update the item document
        transaction.update(itemDoc.reference, {
          'status': 'Distributed',
          'current_holder': receiverName,
          'grr_receipt': _imageUrl,
        });

        // Add a new document to the item_distributions collection
        transaction.set(distributionRef, {
          'distribution_id': distributionRef.id,
          'part_number(sn)': widget.partNumber,
          'distribution_date': Timestamp.now(),
          'receiver_name': receiverName,
          'project_name': projectName,
          'SIV_receipt': _imageUrl,
          'distribution_type': distributionType,
          'account_id': _accountId,
        });
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Item distributed successfully')),
      );
    } catch (e, stackTrace) {
      print('Error distributing item: $e');
      print('Stack trace: $stackTrace');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error distributing item: $e')),
      );
    } finally {
      Navigator.of(context).pop();
    }
  }

  Future<String?> _getCurrentAccountId() async {
    // Placeholder for method to fetch current account ID
    // Implement your logic to get the account ID
    return 'example_account_id'; // Replace with actual logic
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Form(
        key: _formKey,
        child: Column(
          children: [
            TextFormField(
              controller: _receiverNameController,
              decoration: const InputDecoration(labelText: 'Receiver Name'),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter receiver name';
                }
                return null;
              },
            ),
            SizedBox(height: 16.0), // Add spacing
            TextFormField(
              controller: _projectNameController,
              decoration: const InputDecoration(labelText: 'Project Name'),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter project name';
                }
                return null;
              },
            ),
            SizedBox(height: 16.0), // Add spacing
            TextFormField(
              controller: _distributionTypeController,
              decoration: const InputDecoration(labelText: 'Distribution Type'),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter distribution type';
                }
                return null;
              },
            ),
            SizedBox(height: 16.0), // Add spacing
            ElevatedButton(
              onPressed: _uploadImage,
              child: const Text('Upload Image'),
            ),
            if (_imageUrl != null) ...[
              SizedBox(height: 16.0), // Add spacing
              Text('Image Uploaded Successfully'),
              SizedBox(height: 16.0), // Add spacing
              Image.network(_imageUrl!),
            ],
            SizedBox(height: 16.0), // Add spacing
            ElevatedButton(
              onPressed: _distributeItem,
              child: const Text('Distribute Item'),
            ),
          ],
        ),
      ),
    );
  }
}
