import 'package:sos_store_management/index.dart';
import 'package:form_field_validator/form_field_validator.dart';

class RegisterItemPage extends StatefulWidget {
  const RegisterItemPage({super.key});

  @override
  RegisterItemPageState createState() => RegisterItemPageState();
}

class RegisterItemPageState extends State<RegisterItemPage> {
  String imageUrl = '';
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _partNumberController = TextEditingController();
  final TextEditingController _standardnameController = TextEditingController();
  final TextEditingController _brandController = TextEditingController();
  final TextEditingController _modelController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  final TextEditingController _grrReceiptController = TextEditingController();
  final TextEditingController _itemRegistrationDateController =
      TextEditingController();

  final TextEditingController _subtypeController = TextEditingController();
  String _current_holderController = 'Available';
  String _selectedCategory = 'Accessory';

  @override
  void initState() {
    super.initState();
    _itemRegistrationDateController.text =
        DateTime.now().toLocal().toString().split(' ')[0];
  }

  void _resetForm() {
    _formKey.currentState?.reset();
    _partNumberController.clear();
    _standardnameController.clear();
    _brandController.clear();
    _modelController.clear();
    _descriptionController.clear();
    _grrReceiptController.clear();
    _subtypeController.clear();

    setState(() {
      _current_holderController = 'Available';
      _selectedCategory = 'Accessory';
      imageUrl = '';
      _itemRegistrationDateController.text =
          DateTime.now().toLocal().toString().split(' ')[0];
    });
  }

  Future<void> _registerItem() async {
    if (_formKey.currentState?.validate() ?? false) {
      try {
        await FirebaseFirestore.instance.collection('items').add({
          'part_number(sn)': _partNumberController.text,
          'standard_name': _standardnameController.text,
          'brand': _brandController.text,
          'category': _selectedCategory,
          'model': _modelController.text,
          'description': _descriptionController.text,
          'grr_receipt': imageUrl.isNotEmpty ? imageUrl : '',
          'item_registration_date': _itemRegistrationDateController.text,
          'available': _current_holderController,
          'subtype': _subtypeController.text,
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Item registered successfully!')),
        );
        _resetForm();
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    }
  }

  Future<void> _uploadImage() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.image,
      allowMultiple: false,
    );

    if (result == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No file selected.')),
      );
      return;
    }

    PlatformFile file = result.files.first;
    Uint8List? fileBytes = file.bytes;

    if (fileBytes == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Error: File is empty or corrupted.')),
      );
      return;
    }

    String uniqueFileName = DateTime.now().millisecondsSinceEpoch.toString();
    Reference referenceRoot = FirebaseStorage.instance.ref();
    Reference referenceDirImages = referenceRoot.child('grr_receipt');
    Reference referenceImageToUpload = referenceDirImages.child(uniqueFileName);

    try {
      String? mimeType = lookupMimeType(file.name);
      SettableMetadata metadata = SettableMetadata(
        contentType: mimeType,
      );

      await referenceImageToUpload.putData(fileBytes, metadata);
      String downloadURL = await referenceImageToUpload.getDownloadURL();

      setState(() {
        imageUrl = downloadURL;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Image uploaded successfully!')),
      );
    } on FirebaseException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Firebase error: ${e.message}')),
      );
    } catch (error) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error uploading image: $error')),
      );
    }
  }

  @override
  void dispose() {
    _partNumberController.dispose();
    _standardnameController.dispose();
    _brandController.dispose();
    _modelController.dispose();
    _descriptionController.dispose();
    _grrReceiptController.dispose();
    _itemRegistrationDateController.dispose();
    _subtypeController.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Item Registration'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Form(
                key: _formKey,
                child: Column(
                  children: <Widget>[
                    const SizedBox(height: 12),
                    _buildTextField(
                      controller: _partNumberController,
                      label: 'Part Number or Serial Number',
                      hint: 'Part number/S_N',
                      validators: [
                        RequiredValidator(
                            errorText: 'Enter part number or serial number'),
                        MinLengthValidator(3,
                            errorText: 'Minimum 3 characters required'),
                      ],
                    ),
                    const SizedBox(height: 12),
                    _buildTextField(
                      controller: _standardnameController,
                      label: 'Standard Name',
                      hint: 'Enter Standard Name',
                      validators: [
                        RequiredValidator(errorText: 'Enter Standard Name'),
                        MinLengthValidator(3,
                            errorText: 'Minimum 3 characters required'),
                      ],
                    ),
                    const SizedBox(height: 12),
                    _buildDropdown(
                      value: _selectedCategory,
                      onChanged: (String? newValue) {
                        setState(() {
                          _selectedCategory = newValue!;
                        });
                      },
                      validator: RequiredValidator(
                          errorText: 'Please select Item Category'),
                      label: 'Item Category',
                      items: <String>[
                        'Accessory',
                        'Network',
                        'End user Device',
                        'Conferencing',
                        'Power',
                        'Collaboration'
                      ],
                    ),
                    const SizedBox(height: 12),
                    _buildTextField(
                      controller: _subtypeController,
                      label: 'Subtype',
                      hint: 'Enter subtype',
                      validators: [
                        RequiredValidator(errorText: 'Enter a subtype'),
                        MinLengthValidator(3,
                            errorText: 'Enter a valid subtype'),
                      ],
                    ),
                    const SizedBox(height: 12),
                    _buildTextField(
                      controller: _brandController,
                      label: 'Brand',
                      hint: 'Brand',
                      validators: [
                        RequiredValidator(errorText: 'Enter brand'),
                        MinLengthValidator(2, errorText: 'Enter a valid brand'),
                      ],
                    ),
                    const SizedBox(height: 12),
                    _buildTextField(
                      controller: _modelController,
                      label: 'Model',
                      hint: 'Model',
                      validators: [
                        RequiredValidator(errorText: 'Enter model'),
                        MinLengthValidator(3, errorText: 'Enter a valid model'),
                      ],
                    ),
                    const SizedBox(height: 12),
                    _buildTextField(
                      controller: _descriptionController,
                      label: 'Description',
                      hint: 'Description',
                      validators: [
                        RequiredValidator(errorText: 'Enter description'),
                        MinLengthValidator(3,
                            errorText: 'Enter a valid description'),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: IconButton(
                        onPressed: _uploadImage,
                        icon: const Icon(Icons.camera_alt),
                        color: Colors.blue,
                        tooltip: 'Upload Image',
                      ),
                    ),
                    const SizedBox(height: 12),
                    _buildTextField(
                      controller: _itemRegistrationDateController,
                      label: 'Item Registration Date',
                      hint: 'Registration Date',
                      readOnly: true,
                      validators: [
                        RequiredValidator(
                            errorText: 'Select registration date'),
                      ],
                    ),
                    const SizedBox(height: 12),
                    _buildDropdown(
                      value: _current_holderController,
                      onChanged: (String? newValue) {
                        setState(() {
                          _current_holderController = newValue!;
                        });
                      },
                      validator: RequiredValidator(errorText: 'Current Holder'),
                      label: 'Current Holder',
                      items: <String>[
                        'Available',
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: <Widget>[
                        ElevatedButton(
                          onPressed: _registerItem,
                          child: const Text('Register'),
                        ),
                        ElevatedButton(
                          onPressed: _resetForm,
                          child: const Text('Cancel'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required String hint,
    bool readOnly = false,
    required List<FieldValidator<String?>> validators,
  }) {
    return TextFormField(
      controller: controller,
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        border: const OutlineInputBorder(),
      ),
      readOnly: readOnly,
      validator: MultiValidator(validators),
    );
  }

  Widget _buildDropdown({
    required String value,
    required ValueChanged<String?> onChanged,
    required FieldValidator<String?> validator,
    required String label,
    required List<String> items,
  }) {
    return DropdownButtonFormField<String>(
      value: value,
      onChanged: onChanged,
      decoration: InputDecoration(
        labelText: label,
        border: const OutlineInputBorder(),
      ),
      validator: validator,
      items: items.map<DropdownMenuItem<String>>((String value) {
        return DropdownMenuItem<String>(
          value: value,
          child: Text(value),
        );
      }).toList(),
    );
  }
}
