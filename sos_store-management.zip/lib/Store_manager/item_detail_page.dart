import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class ItemDetailPage extends StatelessWidget {
  final String partNumber;

  const ItemDetailPage({super.key, required this.partNumber});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Item Detail - $partNumber'),
      ),
      body: FutureBuilder<Map<String, dynamic>>(
        future: fetchItemDetails(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return const Center(child: Text('Error fetching data'));
          }
          if (!snapshot.hasData) {
            return const Center(child: Text('No data available'));
          }

          final itemData = snapshot.data!['itemData'] as Map<String, dynamic>;
          final distributions =
              snapshot.data!['distributions'] as List<Map<String, dynamic>>;
          final returns =
              snapshot.data!['returns'] as List<Map<String, dynamic>>;

          return SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ListTile(
                  title: const Text('Item Details'),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Part Number: ${itemData['part_number(sn)']}'),
                      Text('Brand: ${itemData['brand']}'),
                      Text('Category: ${itemData['category']}'),
                      Text('Description: ${itemData['description']}'),
                      Text('Model: ${itemData['model']}'),
                      Text('Current Holder: ${itemData['current_holder']}'),
                      Text(
                          'Item Registration Date: ${itemData['item_registration_date'] is Timestamp ? (itemData['item_registration_date'] as Timestamp).toDate().toString() : itemData['item_registration_date']}'),
                      itemData['grr_receipt'] != null
                          ? Image.network(itemData['grr_receipt'])
                          : const Text('GRR Receipt: No Image'),
                    ],
                  ),
                ),
                const Divider(),
                const Text('Distribution History',
                    style:
                        TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: distributions.length,
                  itemBuilder: (context, index) {
                    final distribution = distributions[index];
                    return ListTile(
                      title: Text(
                          'Distribution ID: ${distribution['distribution_id']}'),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                              'Receiver Name: ${distribution['receiver_name']}'),
                          Text('Project Name: ${distribution['project_name']}'),
                          Text(
                              'Distribution Date: ${distribution['distribution_date'] is Timestamp ? (distribution['distribution_date'] as Timestamp).toDate().toString() : distribution['distribution_date']}'),
                          distribution['SIV_receipt'] != null
                              ? Image.network(distribution['SIV_receipt'])
                              : const Text('SIV Receipt: No Image'),
                          Text(
                              'Distribution Type: ${distribution['distribution_type']}'),
                        ],
                      ),
                    );
                  },
                ),
                const Divider(),
                const Text('Return History',
                    style:
                        TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: returns.length,
                  itemBuilder: (context, index) {
                    final returnData = returns[index];
                    return ListTile(
                      title: Text('Return ID: ${returnData['return_id']}'),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                              'Return Date: ${returnData['return_date'] is Timestamp ? (returnData['return_date'] as Timestamp).toDate().toString() : returnData['return_date']}'),
                          Text('Details: ${returnData['details']}'),
                          returnData['grr_receipt'] != null
                              ? Image.network(returnData['grr_receipt'])
                              : const Text('GRR Receipt: No Image'),
                        ],
                      ),
                    );
                  },
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Future<Map<String, dynamic>> fetchItemDetails() async {
    final firestore = FirebaseFirestore.instance;

    // Fetch item data
    final itemSnapshot =
        await firestore.collection('items').doc(partNumber).get();
    final itemData = itemSnapshot.data() ?? {};

    // Fetch distribution history
    final distributionSnapshot = await firestore
        .collection('item_distributions')
        .where('part_number(sn)', isEqualTo: partNumber)
        .get();
    final distributions = distributionSnapshot.docs
        .map((doc) => doc.data() as Map<String, dynamic>)
        .toList();

    // Fetch return history
    final returnSnapshot = await firestore
        .collection('returned_item')
        .where('part_number(sn)', isEqualTo: partNumber)
        .get();
    final returns = returnSnapshot.docs
        .map((doc) => doc.data() as Map<String, dynamic>)
        .toList();

    return {
      'itemData': itemData,
      'distributions': distributions,
      'returns': returns,
    };
  }
}
