import 'index.dart';

class CustomViewPageSearchDelegate extends SearchDelegate<String> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  @override
  List<Widget> buildActions(BuildContext context) {
    return [
      IconButton(
        icon: const Icon(Icons.clear),
        onPressed: () {
          query = '';
          showSuggestions(context); // Show suggestions when clearing query
        },
      ),
    ];
  }

  @override
  Widget buildLeading(BuildContext context) {
    return IconButton(
      icon: AnimatedIcon(
        icon: AnimatedIcons.menu_arrow,
        progress: transitionAnimation,
      ),
      onPressed: () {
        close(context, '');
      },
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    if (query.isEmpty) {
      return const Center(
        child: Text('Your View Page Content'),
      );
    } else {
      // Process the query for part number and registration date
      final queries = query.split(' ');
      String partNumberQuery = '';
      String dateQuery = '';

      if (queries.isNotEmpty) {
        partNumberQuery = queries[0];
        if (queries.length > 1) {
          dateQuery = queries[1];
        }
      }

      // Convert dateQuery to Timestamp if it is a valid date
      Timestamp? dateTimestamp;
      if (dateQuery.isNotEmpty) {
        try {
          final date = DateTime.parse(dateQuery);
          dateTimestamp = Timestamp.fromDate(date);
        } catch (e) {
          // Handle invalid date format
          dateTimestamp = null;
        }
      }

      return FutureBuilder<QuerySnapshot>(
        future: _firestore
            .collection('items')
            .where('part_number(sn)', isGreaterThanOrEqualTo: partNumberQuery)
            .where('part_number(sn)',
                isLessThanOrEqualTo: partNumberQuery + '\uf8ff')
            .get(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return const Center(child: Text('Error fetching data'));
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text('No data available'));
          }

          // Filter items based on dateQuery if it is a valid date
          final items = dateTimestamp != null
              ? snapshot.data!.docs.where((item) {
                  final data = item.data() as Map<String, dynamic>;
                  final itemRegistrationDate = data['item_registration_date'];
                  if (itemRegistrationDate is Timestamp) {
                    return itemRegistrationDate.compareTo(dateTimestamp!) == 0;
                  } else if (itemRegistrationDate is String) {
                    try {
                      final date = DateTime.parse(itemRegistrationDate);
                      return Timestamp.fromDate(date)
                              .compareTo(dateTimestamp!) ==
                          0;
                    } catch (e) {
                      return false;
                    }
                  }
                  return false;
                }).toList()
              : snapshot.data!.docs;

          return SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: DataTable(
              columns: const [
                DataColumn(label: Text('Part Number(SN)')),
                DataColumn(label: Text('Brand')),
                DataColumn(label: Text('Category')),
                DataColumn(label: Text('Description')),
                DataColumn(label: Text('GRR Receipt')),
                DataColumn(label: Text('Item Registration Date')),
                DataColumn(label: Text('Model')),
                DataColumn(label: Text('current_holder')),
              ],
              rows: items.map((item) {
                final data = item.data() as Map<String, dynamic>;
                final grrReceiptUrl = data['grr_receipt'] ?? '';

                return DataRow(
                  cells: [
                    DataCell(Text(data['part_number(sn)'] ?? '')),
                    DataCell(Text(data['brand'] ?? '')),
                    DataCell(Text(data['category'] ?? '')),
                    DataCell(Text(data['description'] ?? '')),
                    DataCell(
                      grrReceiptUrl.isNotEmpty
                          ? GestureDetector(
                              onTap: () {
                                showDialog(
                                  context: context,
                                  builder: (BuildContext context) {
                                    return Dialog(
                                      child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Image.network(grrReceiptUrl),
                                          TextButton(
                                            onPressed: () {
                                              Navigator.of(context).pop();
                                            },
                                            child: const Text('Close'),
                                          ),
                                        ],
                                      ),
                                    );
                                  },
                                );
                              },
                              child: Image.network(
                                grrReceiptUrl,
                                width: 100,
                                height: 100,
                                fit: BoxFit.cover,
                              ),
                            )
                          : const Text('No Image'),
                    ),
                    DataCell(Text(data['item_registration_date'] is Timestamp
                        ? (data['item_registration_date'] as Timestamp)
                            .toDate()
                            .toString()
                        : data['item_registration_date'] is String
                            ? data['item_registration_date']
                            : '')),
                    DataCell(Text(data['model'] ?? '')),
                    DataCell(Text(data['current_holder'] ?? '')),
                  ],
                  onSelectChanged: (bool? selected) {
                    if (selected ?? false) {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ItemDetailPage(
                            partNumber: data['part_number(sn)'],
                          ),
                        ),
                      );
                    }
                  },
                );
              }).toList(),
            ),
          );
        },
      );
    }
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    return query.isEmpty
        ? Container()
        : FutureBuilder<QuerySnapshot>(
            future: _firestore
                .collection('items')
                .where('part_number(sn)', isGreaterThanOrEqualTo: query)
                .where('part_number(sn)', isLessThanOrEqualTo: query + '\uf8ff')
                .get(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }
              if (snapshot.hasError) {
                return const Center(child: Text('Error fetching data'));
              }
              if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                return const Center(child: Text('No suggestions available'));
              }

              final items = snapshot.data!.docs;

              return ListView.builder(
                itemCount: items.length,
                itemBuilder: (context, index) {
                  final item = items[index].data() as Map<String, dynamic>;
                  return ListTile(
                    title: Text(item['part_number(sn)'] ?? ''),
                    onTap: () {
                      query = item['part_number(sn)'] ?? '';
                      showResults(context);
                    },
                  );
                },
              );
            },
          );
  }
}
